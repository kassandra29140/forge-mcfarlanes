# Forge de McFarlane's — comptes + clôture hebdomadaire + historique

## Fonctionnement comptable

La logique suit ton exemple fiscal :

- **période : vendredi → jeudi inclus**
- le **patron peut clôturer manuellement le jeudi**
- si personne ne le fait, le site clôture automatiquement **à minuit après le jeudi**, donc **vendredi 00:00 heure de Paris**
- la clôture crée un **instantané figé** des montants :
  - commandes
  - échoppe
  - charges
  - bénéfice avant impôts
  - impôts
  - bénéfices nets
  - paye patron
- une nouvelle période vendredi → jeudi est créée automatiquement
- les anciennes périodes restent visibles dans **Historique**
- les lignes d'une période clôturée ne peuvent plus être modifiées ou supprimées grâce aux règles RLS de Supabase

## Installation

### 1. Supabase

1. Crée un projet Supabase.
2. Dans **SQL Editor**, exécute `supabase_setup.sql`.
3. Dans **Authentication > Users**, crée ton premier compte.
4. Exécute ensuite la requête indiquée tout en bas du SQL pour mettre ce compte en `admin`.

### 2. config.js

Dans Supabase, récupère l'URL du projet et la clé publique / anon, puis remplace les valeurs de `config.js`.

Ne mets jamais la clé `service_role` dans le navigateur.

### 3. Vercel

Déploie le dossier complet sur Vercel.

Ajoute dans les variables d'environnement du projet :

- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `SITE_URL`
- `CRON_SECRET` — une longue valeur aléatoire de ton choix

Le fichier `vercel.json` lance deux vérifications hebdomadaires, à 22:00 et 23:00 UTC le jeudi.
La fonction `/api/close-week` ne clôture que lorsqu'il est réellement **vendredi 00:00 en Europe/Paris**. Cela gère automatiquement l'heure d'été et l'heure d'hiver.

## Pourquoi deux horaires cron ?

Paris est UTC+2 en été et UTC+1 en hiver.

- été : jeudi 22:00 UTC = vendredi 00:00 Paris
- hiver : jeudi 23:00 UTC = vendredi 00:00 Paris

La fonction vérifie l'heure locale avant de clôturer, donc l'appel qui tombe à la mauvaise heure ne fait rien.

## Historique

La table `accounting_periods` conserve chaque semaine clôturée et ses montants figés.
Même si les taux changent plus tard, l'historique garde le taux d'impôt et la paye patron utilisés au moment de la clôture.
