import { createClient } from '@supabase/supabase-js';
export default async function handler(req,res){
 if(req.method!=='POST')return res.status(405).json({error:'Méthode non autorisée.'});
 const url=process.env.SUPABASE_URL,service=process.env.SUPABASE_SERVICE_ROLE_KEY;
 if(!url||!service)return res.status(500).json({error:'Variables Supabase manquantes.'});
 const token=(req.headers.authorization||'').startsWith('Bearer ')?req.headers.authorization.slice(7):null;
 if(!token)return res.status(401).json({error:'Session manquante.'});
 const admin=createClient(url,service,{auth:{autoRefreshToken:false,persistSession:false}});
 const {data:u,error:ue}=await admin.auth.getUser(token);if(ue||!u?.user)return res.status(401).json({error:'Session invalide.'});
 const {data:p}=await admin.from('profiles').select('role').eq('id',u.user.id).single();if(p?.role!=='admin')return res.status(403).json({error:'Réservé au patron.'});
 const {email,display_name,role}=req.body||{};if(!email||!display_name||!['admin','employee','viewer'].includes(role))return res.status(400).json({error:'Données invalides.'});
 const {data,error}=await admin.auth.admin.inviteUserByEmail(email,{redirectTo:process.env.SITE_URL||undefined,data:{display_name}});
 if(error)return res.status(400).json({error:error.message});
 if(data?.user?.id)await admin.from('profiles').upsert({id:data.user.id,email,display_name,role});
 return res.status(200).json({ok:true});
}
